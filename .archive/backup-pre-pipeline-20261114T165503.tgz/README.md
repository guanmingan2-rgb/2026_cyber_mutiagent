# CyberGym 多角色代码审查与评测记录

这个目录用于 DeepSeek 多角色静态代码审查、CyberGym Level 1 静态消融、离线评分记录整理，以及普通输入的动态评分集成验收。正式 Pilot 的冻结运行器在同级项目 `/home/ybgao/2026_cyber_agents`，其运行和历史结果独立管理。

## 从哪里开始

| 用途 | 入口 | 结果 |
|---|---|---|
| 审查单个源文件 | `review.py` | Manager 分派、Worker 审查、Reviewer 复核，输出 `report.json` |
| 读取并审查单个 CyberGym 任务 | `review_task.py` → `task_materials.py` | 根据显式文件名单生成任务快照、角色交接和最终报告 |
| 运行 Level 1 静态消融 | `cybergym_experiment.py` → `review_task.py` | 按任务和变体输出 `results.csv`、`results.jsonl`、`roles.csv`、`report.json` |
| 整理已有官方评分记录 | `official_report.py` | 核对任务、运行和内容摘要后导出 JSON、CSV。格式见 [离线结果导入](OFFICIAL_RESULT_IMPORT.md) |
| 查阅已有动态集成验收 | `run_dynamic.sbatch`、`cybergym_dynamic.py`、`dynamic_score_backend.py` | 既有普通测试输入验收，见 [验收记录](outputs/deepseek_e2e_validation/integration_report.md) |

静态 Level 1 变体为 `single`、`manager_worker`、`manager_worker_critic` 和 `full`。全角色组依次经过源码映射、分派、分派复核、审查、发现验证和最终筛选。静态任务的官方评分字段为 `not_evaluated`。教学样例及固定回归由 `experiment.py`、`evaluation.py`、`experiment_fixture.py` 和 `teaching_checks.py` 提供，真实题静态入口复用其中的预算与用量统计。

## 环境和代码阅读顺序

项目在服务器上使用同级项目提供的 Python 3.12 环境。也可用 `agent_runtime/install_deepseek.sh` 根据锁定依赖安装本地环境。实际调用已配置模型时，`run_deepseek.sh` 负责选择运行环境和加载凭据。静态消融默认使用本地脚本模型，显式 `--live` 才会访问模型服务。

1. 读 `task_materials.py` 的 `load_task()`，了解题库路径、归档成员筛选、体积限制和快照格式。
2. 读 `review_task.py` 的 `review_task()`，了解角色顺序、验证和交接。
3. 读 `review.py` 的 `ReviewRun`，沿 `agent_runtime/coding.py`、`deepseek.py` 和 `gateway.py` 查看运行时调用与记账。
4. 读 `cybergym_experiment.py` 的 `run()` 和 `official_report.py` 的 `report_rows()`，分别了解静态汇总和离线官方记录关联。查看既有动态作业状态时，`collect_dynamic.py` 会联合核对 Slurm 终态和落盘结果。

## 本地回归

```bash
cd /home/ybgao/2026_cyber_mutiagent
PY=/home/ybgao/2026_cyber_agents/.venv-deepseek-harness/bin/python
"$PY" -B -m unittest discover -v
"$PY" -B -m smoke
"$PY" -B -m smoke_task
```

`smoke` 和 `smoke_task` 使用本地假模型。`agent_runtime/check.py` 属于运行时配置校验。每次新实验使用新的输出目录，`runs/` 和 `outputs/` 中的历史结果、日志和评分记录用于追溯。一次性诊断脚本及旧派发审计说明见 [整理记录](.archive/cleanup-20261114/INDEX.md)。
